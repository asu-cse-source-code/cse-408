% function to create a vocabulary from multiple text files under folders

function voc = buildVoc(folder, voc, finvoc)
stopword = {'ourselves', 'hers', 'between', 'yourself', 'but', 'again', 'there', ...
    'about', 'once', 'during', 'out', 'very', 'having', 'with', 'they', 'own', ...
    'an', 'be', 'some', 'for', 'do', 'its', 'yours', 'such', 'into', ...
    'of', 'most', 'itself', 'other', 'off', 'is', 's', 'am', 'or', ...
    'who', 'as', 'from', 'him', 'each', 'the', 'themselves', 'until', ...
    'below', 'are', 'we', 'these', 'your', 'his', 'through', 'don', 'nor', ...
    'me', 'were', 'her', 'more', 'himself', 'this', 'down', 'should', 'our', ...
    'their', 'while', 'above', 'both', 'up', 'to', 'ours', 'had', 'she', 'all', ...
    'no', 'when', 'at', 'any', 'before', 'them', 'same', 'and', 'been', 'have', ...
    'in', 'will', 'on', 'does', 'yourselves', 'then', 'that', 'because', ...
    'what', 'over', 'why', 'so', 'can', 'did', 'not', 'now', 'under', 'he', ...
    'you', 'herself', 'has', 'just', 'where', 'too', 'only', 'myself', ...
    'which', 'those', 'i', 'after', 'few', 'whom', 't', 'being', 'if', ...
    'theirs', 'my', 'against', 'a', 'by', 'doing', 'it', 'how', ...
    'further', 'was', 'here', 'than', ''}; % define English stop words, from NLTK



files = dir(fullfile(folder,'*.txt'));

for file = files'
    [fid, msg] = fopen(fullfile(folder,file.name), 'rt');
    error(msg);
    line = fgets(fid);                                        % Get the first line from the file
    fileContent = "";                                         % Storing file content into variable fileContent
    while line ~= -1
        %PUT YOUR IMPLEMENTATION HERE
        fileContent = strcat(fileContent, line);               
        line = fgets(fid);
    end
    fclose(fid);
    
    strWithoutPunctuation = erasePunctuation(fileContent);                       % Removing punctuations
    lowercaseStrWithoutPunctuation = lower(strWithoutPunctuation);               % Converting to lower case
    tokenizedWords = split(lowercaseStrWithoutPunctuation);                      % tokenizing words
    tokenizedWords(ismember(tokenizedWords, stopWords)) = [];                    % removing stop words
    for i=1:length(tokenizedWords)
        voc{end+1} = tokenizedWords{i};
    end    
end

[words,~,idx] = unique(voc);       % Performing these functions here for optimizations (running once instead of doing after every file)         
numOccurrences = histcounts(idx,numel(words));
[rankOfOccurrences,rankIndex] = sort(numOccurrences,'descend');
wordsByFrequency = words(rankIndex);
word_array = {};
    for i = 1:length(wordsByFrequency)
       if rankOfOccurrences(i) >= 5                                             % Change threshold here
           word_array{end+1} = wordsByFrequency{i};
       end
    end
voc = word_array;