% function to run KNN classification


function pred_label = cse408_knn(test_feat_set, train_label, train_feat_set, k, DstType)


if DstType == 1 %SSD
    [m,n] = size(train_feat_set);
    dist = zeros(1,n);
    for i=1:n
       dist(i) = sum((test_feat_set-train_feat_set(:,i)).^2);
    end
    
elseif DstType == 2 %Angle Between Vectors
    [m,n] = size(train_feat_set);
    dist = zeros(1,n);
    for i=1:n
        x = train_feat_set(:,i);
        y = test_feat_set;
        cosTheta = dot(x,y)/(norm(x)*norm(y));
        theta = acosd(cosTheta);
        dist(i) = theta;
    end
    
elseif DstType == 3 %Number of words in common
    [m,n] = size(train_feat_set);
    dist = zeros(1,n);
    for i=1:n
       dist(i) = sum(and(train_feat_set(:,i),test_feat_set));
    end
    dist = -dist;               % Minus since smaller the distance, more similar the documents are
end



%Find the top k nearest neighbors, and do the voting. 

[B,I] = sort(dist);

posCt=0;
negCt=0;
for ii = 1:k
    if train_label(I(ii)) == 1
        posCt = posCt + 1;
    elseif train_label(I(ii)) == 0
        negCt = negCt + 1;
    end    
end

if posCt >= negCt
    pred_label = 1;
else
    pred_label = 0;
end