clear all

% make sure you are in the right directory or use full path
posFolder = '../Data/SA/pos';
negFolder = '../Data/SA/neg';

files = dir(fullfile(posFolder,'*.txt'));
for file = files'
    sent_score = sentimentAnalysis(fullfile(posFolder,file.name));
    display(file.name);
    display(['Groundtruth: Positive, sentiment score: ', num2str(sent_score)]);
end

files = dir(fullfile(negFolder,'*.txt'));
for file = files'
    sent_score = sentimentAnalysis(fullfile(negFolder,file.name));
    display(file.name);
    display(['Groundtruth: Negative, sentiment score: ', num2str(sent_score)]);
end


% Proposed improvements. Uncomment this code to run the proposed
% improvements solution

% files = dir(fullfile(posFolder,'*.txt'));
% for file = files'
%     sent_score = sentimentAnalysisImprovement(fullfile(posFolder,file.name));
%     display(file.name);
%     display(['Groundtruth: Positive, sentiment score: ', num2str(sent_score)]);
% end
% 
% files = dir(fullfile(negFolder,'*.txt'));
% for file = files'
%     sent_score = sentimentAnalysisImprovement(fullfile(negFolder,file.name));
%     display(file.name);
%     display(['Groundtruth: Negative, sentiment score: ', num2str(sent_score)]);
% end