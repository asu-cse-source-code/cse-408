% function sentimentAnalysis
% Input: a path to the target text file
% Output: a sentiment score of the text

function sent_score = sentimentAnalysisImprovement(filename)

% make sure you are in the right directory or use full path
lexicon = '../Data/SA/wordwithStrength.txt';

[fid, msg] = fopen(lexicon, 'rt');
error(msg);
line = fgets(fid); % Get the first line from the file.
 
%Initialize a Map structure to store the lexicon
cM = containers.Map();
while line ~= -1

    % fprintf('%s', line); % Print the line on
    ii = 1;
    token={};
    while any(line)
        [token{ii}, line] = strtok(line);
        % Repeatedly apply the strtok function.
        ii = ii + 1; 
    end
    cM(token{1}) = str2double(token{2});
    
    line = fgets(fid); % Get the next line from the file.
end
fclose(fid);


[fid, msg] = fopen(filename, 'rt');
error(msg);
line = fgets(fid); % Get the first line from the file.
test_token={};
ii = 1;
fileContent = "";                                         % Storing file content into variable fileContent
while line ~= -1
     %Store each word in the test_token array
     fileContent = strcat(fileContent, line);               
     line = fgets(fid);
end

strWithoutPunctuation = erasePunctuation(fileContent);                       % Removing punctuations
lowercaseStrWithoutPunctuation = lower(strWithoutPunctuation);               % Converting to lower case
tokenizedWords = split(lowercaseStrWithoutPunctuation);                      % tokenizing words
tokenizedWords(ismember(tokenizedWords, stopWords)) = [];                    % removing stop words
tokenizedWords = unique(tokenizedWords);
for i=1:length(tokenizedWords)
   test_token{end+1} = tokenizedWords{i};
end

fclose(fid);

sent_score = 0;
prev_score = 0;                                        % Providing context of previous word
for k=1:length(test_token)                                  
    if isKey(cM, test_token{k}) == 1
        if prev_score > 0 && cM(test_token{k}) < 0     % Neutralizing the effect of a positive word in a negative connotation
            sent_score = sent_score - prev_score;            
        end
        sent_score = cM(test_token{k}) + sent_score;        
        prev_score = cM(test_token{k});
    else
        prev_score = 0;                                % Context should only be provided by simultaneous words
    end
end 