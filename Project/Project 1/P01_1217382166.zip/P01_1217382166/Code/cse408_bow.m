% function to create a vocabulary from multiple text files under folders

function feat_vec = cse408_bow(filepath, voc)

[fid, msg] = fopen(filepath, 'rt');
error(msg);
line = fgets(fid);                                        % Get the first line from the file
fileContent = "";                                         % Storing file content into variable fileContent
   while line ~= -1
       %PUT YOUR IMPLEMENTATION HERE
       fileContent = strcat(fileContent, line);               
       line = fgets(fid);
   end
feat_vec = zeros(size(voc)); %Initialize the feature vector'
documentVocab = {};
strWithoutPunctuation = erasePunctuation(fileContent);                       % Removing punctuations
lowercaseStrWithoutPunctuation = lower(strWithoutPunctuation);               % Converting to lower case
tokenizedWords = split(lowercaseStrWithoutPunctuation);                      % tokenizing words
tokenizedWords(ismember(tokenizedWords, stopWords)) = [];                    % removing stop words
   for i=1:length(tokenizedWords)
      documentVocab{end+1} = tokenizedWords{i};
   end
  
for i = 1:length(documentVocab)
   for j = 1:length(voc)
     if strcmp(documentVocab{i}, voc{j})
       feat_vec(j) = feat_vec(j) + 1;
     end
   end
end

fclose(fid);